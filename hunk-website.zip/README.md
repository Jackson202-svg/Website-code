# 💪 Hunk Profile Website

A modern responsive personal profile webpage built with **HTML**, **CSS**, and **JavaScript**.

## Features
- 🔥 Clean and modern design
- 🌗 Light/Dark theme toggle
- ❤️ “Follow” button with animation
- 🖼️ Responsive gallery layout
- 📱 Works on desktop and mobile

## Folder Structure
```
hunk-website/
├── index.html
├── style.css
├── script.js
└── README.md
```

## How to Run
1. Download and unzip the project.
2. Open `index.html` in your browser.

Enjoy! 🎉
