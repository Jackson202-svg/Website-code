const toggleBtn = document.getElementById("theme-toggle");
toggleBtn.addEventListener("click", () => {
  document.body.classList.toggle("light");
});
const followBtn = document.querySelector(".follow-btn");
followBtn.addEventListener("click", () => {
  if (followBtn.textContent === "Follow") {
    followBtn.textContent = "Following ❤️";
  } else {
    followBtn.textContent = "Follow";
  }
});